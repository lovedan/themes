eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(5(a){4(1t 1l!=="1h"&&1l.2z){1l([],a)}X{4(1t 1y!=="1h"&&1y.1G){1y.1G=a()}X{13.1O=a()}}})(5(){3 c=5(){11 13.23||(Z.18&&Z.18.1X)||Z.1k.1X};3 G={};3 V=24;3 k=[];3 E="25";3 B="26";3 z="28";3 o="2i";3 l="2j";3 w="2l";3 n="2m";3 p=[E,B,z,o,l,w,n];3 F={7:0,6:0};3 y=5(){11 13.22||Z.18.1L};3 a=5(){11 2o.2q(Z.1k.1I,Z.18.1I,Z.1k.1w,Z.18.1w,Z.18.1L)};G.15=1d;G.1b=1d;G.1a=1d;G.1A=y();3 v;3 s;3 b;5 t(){G.15=c();G.1b=G.15+G.1A;G.1a=a();4(G.1a!==v){b=k.Y;1i(b--){k[b].1j()}v=G.1a}}5 r(){G.1A=y();t();q()}3 d;5 u(){2r(d);d=2y(r,2B)}3 h;5 q(){h=k.Y;1i(h--){k[h].19()}h=k.Y;1i(h--){k[h].1D()}}5 m(P,I){3 S=2;2.9=P;4(!I){2.16=F}X{4(I===+I){2.16={7:I,6:I}}X{2.16={7:I.7||F.7,6:I.6||F.6}}}2.8={};1c(3 N=0,M=p.Y;N<M;N++){S.8[p[N]]=[]}2.1e=1o;3 L;3 Q;3 R;3 O;3 H;3 e;5 K(i){4(i.Y===0){11}H=i.Y;1i(H--){e=i[H];e.1q.1p(S,s);4(e.1E){i.1m(H,1)}}}2.1D=5 J(){4(2.W&&!L){K(2.8[B])}4(2.14&&!Q){K(2.8[z])}4(2.12!==R&&2.17!==O){K(2.8[E]);4(!Q&&!2.14){K(2.8[z]);K(2.8[l])}4(!L&&!2.W){K(2.8[B]);K(2.8[o])}}4(!2.14&&Q){K(2.8[l])}4(!2.W&&L){K(2.8[o])}4(2.W!==L){K(2.8[E])}1K(1g){10 L!==2.W:10 Q!==2.14:10 R!==2.12:10 O!==2.17:K(2.8[n])}L=2.W;Q=2.14;R=2.12;O=2.17};2.1j=5(){4(2.1e){11}3 U=2.7;3 T=2.6;4(2.9.2k){3 j=2.9.1z.1x;4(j==="1Q"){2.9.1z.1x=""}3 i=2.9.27();2.7=i.7+G.15;2.6=i.6+G.15;4(j==="1Q"){2.9.1z.1x=j}}X{4(2.9===+2.9){4(2.9>0){2.7=2.6=2.9}X{2.7=2.6=G.1a-2.9}}X{2.7=2.9.7;2.6=2.9.6}}2.7-=2.16.7;2.6+=2.16.6;2.1u=2.6-2.7;4((U!==1h||T!==1h)&&(2.7!==U||2.6!==T)){K(2.8[w])}};2.1j();2.19();L=2.W;Q=2.14;R=2.12;O=2.17}m.1S={1s:5(e,j,i){1K(1g){10 e===E&&!2.W&&2.12:10 e===B&&2.W:10 e===z&&2.14:10 e===o&&2.12&&!2.W:10 e===l&&2.12:j.1p(2,s);4(i){11}}4(2.8[e]){2.8[e].1U({1q:j,1E:i||1o})}X{1n 1f 1B("1Y 1Z 2n a 1v 21 20 1W 1V "+e+". 1T 1C 1R: "+p.1P(", "))}},29:5(H,I){4(2.8[H]){1c(3 e=0,j;j=2.8[H][e];e++){4(j.1q===I){2.8[H].1m(e,1);2a}}}X{1n 1f 1B("1Y 1Z 2b a 1v 21 20 1W 1V "+H+". 1T 1C 1R: "+p.1P(", "))}},2c:5(e,i){2.1s(e,i,1g)},2d:5(){2.1u=2.9.1w+2.16.7+2.16.6;2.6=2.7+2.1u},19:5(){2.12=2.7<G.15;2.17=2.6>G.1b;2.W=(2.7<=G.1b&&2.6>=G.15);2.14=(2.7>=G.15&&2.6<=G.1b)||(2.12&&2.17)},2e:5(){3 I=k.2f(2),e=2;k.1m(I,1);1c(3 J=0,H=p.Y;J<H;J++){e.8[p[J]].Y=0}},2g:5(){2.1e=1g},2h:5(){2.1e=1o}};3 g=5(e){11 5(j,i){2.1s.1p(2,e,j,i)}};1c(3 C=0,A=p.Y;C<A;C++){3 f=p[C];m.1S[f]=g(f)}1N{t()}1M(D){1N{13.$(t)}1M(D){1n 1f 1B("2p 1J 1H 2s 1O 2t 2u <2v>, 1J 1H 2w 2x.")}}5 x(e){s=e;t();q()}4(13.1r){13.1r("1v",x);13.1r("2A",u)}X{13.1F("2C",x);13.1F("2D",u)}G.2E=G.2F=5(i,j){4(1t i==="2G"){i=Z.2H(i)}X{4(i&&i.Y>0){i=i[0]}}3 e=1f m(i,j);k.1U(e);e.19();11 e};G.19=5(){s=1d;t();q()};G.2I=5(){G.1a=0;G.19()};11 G});',62,169,'||this|var|if|function|bottom|top|callbacks|watchItem|||||||||||||||||||||||||||||||||||||||||||||||||isInViewport|else|length|document|case|return|isAboveViewport|window|isFullyInViewport|viewportTop|offsets|isBelowViewport|documentElement|update|documentHeight|viewportBottom|for|null|locked|new|true|undefined|while|recalculateLocation|body|define|splice|throw|false|call|callback|addEventListener|on|typeof|height|scroll|offsetHeight|display|module|style|viewportHeight|Error|options|triggerCallbacks|isOne|attachEvent|exports|must|scrollHeight|you|switch|clientHeight|catch|try|scrollMonitor|join|none|are|prototype|Your|push|type|of|scrollTop|Tried|to|listener|monitor|innerHeight|pageYOffset|000|visibilityChange|enterViewport|getBoundingClientRect|fullyEnterViewport|off|break|remove|one|recalculateSize|destroy|indexOf|lock|unlock|exitViewport|partiallyExitViewport|nodeName|locationChange|stateChange|add|Math|If|max|clearTimeout|put|in|the|head|use|jQuery|setTimeout|amd|resize|100|onscroll|onresize|beget|create|string|querySelector|recalculateLocations'.split('|'),0,{}))

$(document).ready(function() {
	// 菜单
	var $account = $('#top-header');
	var $header = $('#menu-box, #search-main, #mobile-nav');
	var $minisb = $('#content');
	var $footer = $('#footer');

	var accountWatcher = scrollMonitor.create($account);
	var headerWatcher = scrollMonitor.create($header);

	var footerWatcherTop = $minisb.height() + $header.height();
	var footerWatcher = scrollMonitor.create($footer, {
		top: footerWatcherTop
	});

	accountWatcher.lock();
	headerWatcher.lock();

	accountWatcher.visibilityChange(function() {
		$header.toggleClass('shadow', !accountWatcher.isInViewport);
	});
	headerWatcher.visibilityChange(function() {
		$minisb.toggleClass('shadow', !headerWatcher.isInViewport);
	});

	footerWatcher.fullyEnterViewport(function() {
		if (footerWatcher.isAboveViewport) {
			$minisb.removeClass('shadow').addClass('hug-footer')
		}
	});
	footerWatcher.partiallyExitViewport(function() {
		if (!footerWatcher.isAboveViewport) {
			$minisb.addClass('fixed').removeClass('hug-footer')
		}
	});
});

$(document).ready(function(a) {
	// removeClass
	if (typeof scrollMonitor != 'undefined') {
		a(".wow").each(function(i, el) {
			var ael = a(el),
			watcher = scrollMonitor.create(el, -100);
			ael.addClass('wow');
			watcher.enterViewport(function(ev) {
				ael.removeClass('fadeInUp');
			});
		});
	}
})

$(document).ready(function() {
	// 跟随
	var $account = $('#sidebar');
	var $header = $('.sidebar-roll');
	var $minisb = $('#content');
	var $footer = $('#footer');

	var accountWatcher = scrollMonitor.create($account);
	var headerWatcher = scrollMonitor.create($header);

	var footerWatcherTop = $minisb.height() + $header.height();

	accountWatcher.lock();
	headerWatcher.lock();

	accountWatcher.visibilityChange(function() {
		$header.toggleClass('follow', !accountWatcher.isInViewport);
	});
});

$(document).ready(function() {
// 搜索
$(".nav-search").click(function() {
	$("#search-main").fadeToggle(300);
});

// 菜单
$(".nav-mobile").click(function() {
	$("#mobile-nav").slideToggle(500);
});

// 引用
$(".backs").click(function() {
	$(".track").slideToggle("slow");
	return false;
});

// 弹出层
$(".qr").mouseover(function() {
	$(this).children(".qr-img").fadeIn(300);
});
$(".qr").mouseout(function() {
	$(this).children(".qr-img").hide();
});

$(".share-sd").mouseover(function() {
	$(this).children("#share").show();
});
$(".share-sd").mouseout(function() {
	$(this).children("#share").hide();
});

$(".qqonline").mouseover(function() {
	$(this).children(".qqonline-box").show();
})
$(".qqonline").mouseout(function() {
	$(this).children(".qqonline-box").hide();
});

// 邀请码
$('.to-code').click(function() {
	$('.to-code-way').animate({
		opacity: 'toggle'
	},
	300);
	return false;
});

// 关闭
$('.shut-error').click(function() {
	$('.user_error').animate({
		opacity: 'toggle'
	},
	100);
	return false;
});

// 文字展开
$(".show-more span").click(function(e) {
	$(this).html(["<i class='fa fa-caret-down'></i>", "<i class='fa fa-caret-up'></i>"][this.hutia ^= 1]);
	$(this.parentNode.parentNode).next().slideToggle();
	e.preventDefault();
});

// 滚屏
$('.scroll-h').click(function() {
	$('html,body').animate({
		scrollTop: '0px'
	},
	800);
});
$('.scroll-c').click(function() {
	$('html,body').animate({
		scrollTop: $('.scroll-comments').offset().top
	},
	800);
});
$('.scroll-b').click(function() {
	$('html,body').animate({
		scrollTop: $('.site-info').offset().top
	},
	800);
});

// 去边线
$(".message-widget li:last, .message-page li:last, .hot_commend li:last, .search-page li:last, .my-comment li:last").css("border", "none");

// 表情
$('.emoji').click(function() {
	$('.emoji-box').animate({
		opacity: 'toggle',
		left: '50px'
	},
	1000).animate({
		left: '10px'
	},
	'fast');
	return false;
});

// 登录
$('#login-main, #login-mobile').leanModal({
	top: 110,
	overlay: 0.6,
	closeButton: '.hidemodal'
});

// 字号
$("#fontsize").click(function() {
	var _this = $(this);
	var _t = $(".single-content");
	var _c = _this.attr("class");
	if (_c == "size_s") {
		_this.removeClass("size_s").addClass("size_l");
		_this.text("A+");
		_t.removeClass("fontsmall").addClass("fontlarge");
	} else {
		_this.removeClass("size_l").addClass("size_s");
		_this.text("A-");
		_t.removeClass("fontlarge").addClass("fontsmall");
	};
});

// 目录
if (document.body.clientWidth > 1024) {
	$(function() {
		$(window).scroll(function() {
			if ($("#log-box").html() != undefined) {
				var h = $("#title-2").offset().top;
				if ($(this).scrollTop() > h && $(this).scrollTop() < h + 50) {
					$("#log-box").show();
				}
				var h = $("#title-1").offset().top;
				if ($(this).scrollTop() > h && $(this).scrollTop() < h + 50) {
					$("#log-box").hide();
				}
			}
		});
	})
}

$(".log-button, .log-close").click(function() {
	$("#log-box").fadeToggle(300);
});

if ($("#log-box").length > 0) {
	$(".log").removeClass("log-no");
}
$('.log-prompt').show().delay(5000).fadeOut();

// 图片延迟
$(".load img, .single-content img,.avatar").lazyload({
	effect: "fadeIn",
	failure_limit: 70
});

// 锚链接
$('#catalog a[href*=#],area[href*=#]').click(function() {
	if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
		var $target = $(this.hash);
		$target = $target.length && $target || $('[name=' + this.hash.slice(1) + ']');
		if ($target.length) {
			var targetOffset = $target.offset().top;
			$('html,body').animate({
				scrollTop: targetOffset
			},
			800);
			return false;
		}
	}
});

// 图片数量
var i = $('#gallery .fancybox').size();
$('.myimg').html(' ' + i + ' 张图片');

// 结束
});

$(document).ready(function() {
	$('#tip-w').tipso({
		useTitle: false,
		background: '#f1f1f1'
	});
	$('#tip-w-j').tipso({
		useTitle: false,
		background: '#f1f1f1'
	});
	$('#tip-p').tipso({
		useTitle: false,
		background: '#f1f1f1',
		width: '300px',
		color: '#444'
	});
});

// 隐藏侧边
function pr() {
	var R = document.getElementById("sidebar");
	var L = document.getElementById("primary");
	if (R.className == "sidebar") {
		R.className = "sidebar-hide";
		L.className = "";
	} else {
		R.className = "sidebar";
		L.className = "primary";
	}
}

// 链接复制
function copy_code(text) {
	if (window.clipboardData) {
		window.clipboardData.setData("Text", text);
		alert("已经成功将原文链接复制到剪贴板！");
	} else {
		var x = prompt('你的浏览器可能不能正常复制\n请您手动进行：', text);
	}
};

// 评论贴图
function embedImage() {
	var URL = prompt('请输入图片 URL 地址:', 'http://');
	if (URL) {
		document.getElementById('comment').value = document.getElementById('comment').value + '[img]' + URL + '[/img]';
	}
};
// 文字滚动
(function($) {
	$.fn.textSlider = function(settings) {
		settings = jQuery.extend({
			speed: "normal",
			line: 2,
			timer: 1000
		},
		settings);
		return this.each(function() {
			$.fn.textSlider.scllor($(this), settings)
		})
	};
	$.fn.textSlider.scllor = function($this, settings) {
		var ul = $("ul:eq(0)", $this);
		var timerID;
		var li = ul.children();
		var _btnUp = $(".up:eq(0)", $this);
		var _btnDown = $(".down:eq(0)", $this);
		var liHight = $(li[0]).height();
		var upHeight = 0 - settings.line * liHight;
		var scrollUp = function() {
			_btnUp.unbind("click", scrollUp);
			ul.animate({
				marginTop: upHeight
			},
			settings.speed,
			function() {
				for (i = 0; i < settings.line; i++) {
					ul.find("li:first").appendTo(ul)
				}
				ul.css({
					marginTop: 0
				});
				_btnUp.bind("click", scrollUp)
			})
		};
		var scrollDown = function() {
			_btnDown.unbind("click", scrollDown);
			ul.css({
				marginTop: upHeight
			});
			for (i = 0; i < settings.line; i++) {
				ul.find("li:last").prependTo(ul)
			}
			ul.animate({
				marginTop: 0
			},
			settings.speed,
			function() {
				_btnDown.bind("click", scrollDown)
			})
		};
		var autoPlay = function() {
			timerID = window.setInterval(scrollUp, settings.timer)
		};
		var autoStop = function() {
			window.clearInterval(timerID)
		};
		ul.hover(autoStop, autoPlay).mouseout();
		_btnUp.css("cursor", "pointer").click(scrollUp);
		_btnUp.hover(autoStop, autoPlay);
		_btnDown.css("cursor", "pointer").click(scrollDown);
		_btnDown.hover(autoStop, autoPlay)
	}
})(jQuery);

// 表情
function grin(a) {
	var d;
	a = " " + a + " ";
	if (document.getElementById("comment") && document.getElementById("comment").type == "textarea") {
		d = document.getElementById("comment")
	} else {
		return false
	}
	if (document.selection) {
		d.focus();
		sel = document.selection.createRange();
		sel.text = a;
		d.focus()
	} else {
		if (d.selectionStart || d.selectionStart == "0") {
			var c = d.selectionStart;
			var b = d.selectionEnd;
			var e = b;
			d.value = d.value.substring(0, c) + a + d.value.substring(b, d.value.length);
			e += a.length;
			d.focus();
			d.selectionStart = e;
			d.selectionEnd = e
		} else {
			d.value += a;
			d.focus()
		}
	}
};

// 弹窗
(function(a) {
	a.fn.extend({
		leanModal: function(d) {
			var e = {
				top: 100,
				overlay: 0.5,
				closeButton: null
			};
			var c = a("<div id='overlay'></div>");
			a("body").append(c);
			d = a.extend(e, d);
			return this.each(function() {
				var f = d;
				a(this).click(function(j) {
					var i = a(this).attr("href");
					a("#overlay").click(function() {
						b(i)
					});
					a(f.closeButton).click(function() {
						b(i)
					});
					var h = a(i).outerHeight();
					var g = a(i).outerWidth();
					a("#overlay").css({
						"display": "block",
						opacity: 0
					});
					a("#overlay").fadeTo(200, f.overlay);
					a(i).css({
						"display": "block",
						"position": "fixed",
						"opacity": 0,
						"z-index": 11000,
						"left": 50 + "%",
						"margin-left": -(g / 2) + "px",
						"top": f.top + "px"
					});
					a(i).fadeTo(200, 1);
					j.preventDefault()
				})
			});
			function b(f) {
				a("#overlay").fadeOut(200);
				a(f).css({
					"display": "none"
				})
			}
		}
	})
})(jQuery);

// 喜欢
$.fn.postLike = function() {
	if (jQuery(this).hasClass("done")) {
		return false
	} else {
		$(this).addClass("done");
		var d = $(this).data("id"),
		c = $(this).data("action"),
		b = jQuery(this).children(".count");
		var a = {
			action: "zm_ding",
			um_id: d,
			um_action: c
		};
		$.post(wpl_ajax_url, a,
		function(e) {
			jQuery(b).html(e)
		});
		return false
	}
};
$(document).on("click", ".favorite",
function() {
	$(this).postLike()
});